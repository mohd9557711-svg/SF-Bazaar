# SF BAZAAR Android Project

This is the Android Studio project wrapper for the SF BAZAAR prototype.

## Included
- Original SF BAZAAR shopping UI
- Home, Categories, Search, Products, Cart, Orders, Profile and Seller sections
- Android WebView shell and offline local HTML asset
- INTERNET permission for future API/payment integration

## Build
Open this folder in Android Studio and let it sync the Android Gradle Plugin. Then use Build > Build APK(s).

## Important
The project does not include real payment credentials, production backend, seller KYC, order database, or live shipping APIs. Those require production services and credentials. The current app is the coded front-end/prototype packaged as an Android project.
